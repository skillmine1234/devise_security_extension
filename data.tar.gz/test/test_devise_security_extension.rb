require 'helper'

class TestDeviseSecurityExtension < Test::Unit::TestCase
  def test_something_for_real
  end
end
