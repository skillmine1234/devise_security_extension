class SecurityQuestion < ActiveRecord::Base
  
end
